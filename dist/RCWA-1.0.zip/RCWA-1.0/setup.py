from distutils.core import setup

setup(name='RCWA',
      version='1.0',
      description='rigorous coupled wave analysis module',
      author='Nathan Zhao',
      author_email='nzz2102@stanford.edu',
     )
# packages=['distutils', 'distutils.command'],

